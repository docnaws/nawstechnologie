# Nawstechnologie
Site vitrine bilingue FR/NL, responsive et sans framework.

## GitHub Pages
1. Créez un compte GitHub.
2. Créez un dépôt public `nawstechnologie`.
3. Envoyez tout le contenu de ce dossier à la racine.
4. Settings → Pages → Deploy from a branch → main → / (root) → Save.
5. Le site sera disponible sur `https://VOTRE-PSEUDO.github.io/nawstechnologie/`.

Avant publication, remplacez dans `index.html` les quatre champs `[NUMÉRO...]`, `[ADRESSE EMAIL]` et `[ZONE...]`. Remplacez aussi VOTRE-PSEUDO dans robots.txt et sitemap.xml.
